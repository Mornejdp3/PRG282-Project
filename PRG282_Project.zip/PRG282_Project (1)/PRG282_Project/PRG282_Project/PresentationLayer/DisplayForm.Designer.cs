﻿namespace PRG282_Project.PresentationLayer
{
    partial class DisplayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            StudentView = new DataGridView();
            SearchButton = new Button();
            ViewAllButton = new Button();
            StudentNumberBox = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)StudentView).BeginInit();
            SuspendLayout();
            // 
            // StudentView
            // 
            StudentView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            StudentView.Location = new Point(22, 22);
            StudentView.Margin = new Padding(3, 2, 3, 2);
            StudentView.Name = "StudentView";
            StudentView.RowHeadersWidth = 51;
            StudentView.RowTemplate.Height = 29;
            StudentView.Size = new Size(687, 217);
            StudentView.TabIndex = 0;
            // 
            // SearchButton
            // 
            SearchButton.Location = new Point(190, 278);
            SearchButton.Margin = new Padding(3, 2, 3, 2);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(82, 22);
            SearchButton.TabIndex = 1;
            SearchButton.Text = "Search";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // ViewAllButton
            // 
            ViewAllButton.Location = new Point(436, 278);
            ViewAllButton.Margin = new Padding(3, 2, 3, 2);
            ViewAllButton.Name = "ViewAllButton";
            ViewAllButton.Size = new Size(82, 22);
            ViewAllButton.TabIndex = 2;
            ViewAllButton.Text = "View All";
            ViewAllButton.UseVisualStyleBackColor = true;
            ViewAllButton.Click += ViewAllButton_Click;
            // 
            // StudentNumberBox
            // 
            StudentNumberBox.Location = new Point(286, 279);
            StudentNumberBox.Margin = new Padding(3, 2, 3, 2);
            StudentNumberBox.Mask = "00000000";
            StudentNumberBox.Name = "StudentNumberBox";
            StudentNumberBox.Size = new Size(117, 23);
            StudentNumberBox.TabIndex = 3;
            // 
            // DisplayForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(736, 363);
            Controls.Add(StudentNumberBox);
            Controls.Add(ViewAllButton);
            Controls.Add(SearchButton);
            Controls.Add(StudentView);
            Margin = new Padding(3, 2, 3, 2);
            Name = "DisplayForm";
            Text = "DisplayForm";
            Load += DisplayForm_Load;
            ((System.ComponentModel.ISupportInitialize)StudentView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView StudentView;
        private Button SearchButton;
        private Button ViewAllButton;
        private MaskedTextBox StudentNumberBox;
    }
}