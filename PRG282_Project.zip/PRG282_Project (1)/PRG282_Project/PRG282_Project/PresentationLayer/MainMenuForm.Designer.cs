﻿namespace PRG282_Project
{
    partial class MainMenuForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            StudentNumberBox = new MaskedTextBox();
            FirstNameBox = new TextBox();
            SurnameBox = new TextBox();
            PictureBox = new PictureBox();
            DateOfBirth = new DateTimePicker();
            GenderListBox = new ListBox();
            PhoneBox = new MaskedTextBox();
            StreetAddressBox = new TextBox();
            UpdateButton = new Button();
            DeregisterButton = new Button();
            StudentsView = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            button1 = new Button();
            addStudent = new Button();
            button2 = new Button();
            EditModulesButton = new Button();
            ((System.ComponentModel.ISupportInitialize)PictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)StudentsView).BeginInit();
            SuspendLayout();
            // 
            // StudentNumberBox
            // 
            StudentNumberBox.Location = new Point(59, 47);
            StudentNumberBox.Mask = "00000000";
            StudentNumberBox.Name = "StudentNumberBox";
            StudentNumberBox.Size = new Size(125, 27);
            StudentNumberBox.TabIndex = 0;
            // 
            // FirstNameBox
            // 
            FirstNameBox.Location = new Point(59, 80);
            FirstNameBox.Name = "FirstNameBox";
            FirstNameBox.Size = new Size(125, 27);
            FirstNameBox.TabIndex = 1;
            // 
            // SurnameBox
            // 
            SurnameBox.Location = new Point(59, 113);
            SurnameBox.Name = "SurnameBox";
            SurnameBox.Size = new Size(125, 27);
            SurnameBox.TabIndex = 2;
            // 
            // PictureBox
            // 
            PictureBox.BackColor = Color.White;
            PictureBox.BackgroundImageLayout = ImageLayout.Stretch;
            PictureBox.BorderStyle = BorderStyle.FixedSingle;
            PictureBox.InitialImage = null;
            PictureBox.Location = new Point(59, 328);
            PictureBox.Margin = new Padding(2, 3, 2, 3);
            PictureBox.Name = "PictureBox";
            PictureBox.Size = new Size(258, 182);
            PictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            PictureBox.TabIndex = 3;
            PictureBox.TabStop = false;
            PictureBox.Click += PictureBox_Click;
            // 
            // DateOfBirth
            // 
            DateOfBirth.CustomFormat = "yyyy/MM/dd";
            DateOfBirth.Format = DateTimePickerFormat.Custom;
            DateOfBirth.Location = new Point(59, 157);
            DateOfBirth.Name = "DateOfBirth";
            DateOfBirth.Size = new Size(125, 27);
            DateOfBirth.TabIndex = 4;
            // 
            // GenderListBox
            // 
            GenderListBox.FormattingEnabled = true;
            GenderListBox.ItemHeight = 20;
            GenderListBox.Items.AddRange(new object[] { "Female", "Male" });
            GenderListBox.Location = new Point(59, 191);
            GenderListBox.Name = "GenderListBox";
            GenderListBox.Size = new Size(125, 24);
            GenderListBox.TabIndex = 5;
            // 
            // PhoneBox
            // 
            PhoneBox.Location = new Point(59, 221);
            PhoneBox.Mask = "(999) 000-0000";
            PhoneBox.Name = "PhoneBox";
            PhoneBox.Size = new Size(125, 27);
            PhoneBox.TabIndex = 6;
            // 
            // StreetAddressBox
            // 
            StreetAddressBox.Location = new Point(59, 253);
            StreetAddressBox.Name = "StreetAddressBox";
            StreetAddressBox.Size = new Size(125, 27);
            StreetAddressBox.TabIndex = 7;
            // 
            // UpdateButton
            // 
            UpdateButton.Location = new Point(709, 533);
            UpdateButton.Name = "UpdateButton";
            UpdateButton.Size = new Size(112, 29);
            UpdateButton.TabIndex = 10;
            UpdateButton.Text = "Update Student";
            UpdateButton.UseVisualStyleBackColor = true;
            UpdateButton.Click += UpdateButton_Click;
            // 
            // DeregisterButton
            // 
            DeregisterButton.Location = new Point(944, 533);
            DeregisterButton.Name = "DeregisterButton";
            DeregisterButton.Size = new Size(112, 29);
            DeregisterButton.TabIndex = 13;
            DeregisterButton.Text = "Deregister";
            DeregisterButton.UseVisualStyleBackColor = true;
            DeregisterButton.Click += DeregisterButton_Click;
            // 
            // StudentsView
            // 
            StudentsView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            StudentsView.Location = new Point(502, 51);
            StudentsView.Name = "StudentsView";
            StudentsView.RowHeadersWidth = 51;
            StudentsView.RowTemplate.Height = 29;
            StudentsView.Size = new Size(753, 460);
            StudentsView.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(209, 51);
            label1.Name = "label1";
            label1.Size = new Size(118, 20);
            label1.TabIndex = 16;
            label1.Text = "Student Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(209, 87);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 17;
            label2.Text = "First Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(209, 120);
            label3.Name = "label3";
            label3.Size = new Size(67, 20);
            label3.TabIndex = 18;
            label3.Text = "Surname";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(129, 305);
            label4.Name = "label4";
            label4.Size = new Size(127, 20);
            label4.TabIndex = 19;
            label4.Text = "Picture of Student";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(209, 163);
            label5.Name = "label5";
            label5.Size = new Size(94, 20);
            label5.TabIndex = 20;
            label5.Text = "Date of Birth";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(209, 195);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 21;
            label6.Text = "Gender";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(209, 224);
            label7.Name = "label7";
            label7.Size = new Size(50, 20);
            label7.TabIndex = 22;
            label7.Text = "Phone";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(209, 261);
            label8.Name = "label8";
            label8.Size = new Size(105, 20);
            label8.TabIndex = 23;
            label8.Text = "Street Address";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(848, 28);
            label9.Name = "label9";
            label9.Size = new Size(66, 20);
            label9.TabIndex = 24;
            label9.Text = "Students";
            // 
            // button1
            // 
            button1.Location = new Point(129, 517);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(126, 32);
            button1.TabIndex = 25;
            button1.Text = "Upload Picture";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // addStudent
            // 
            addStudent.Location = new Point(502, 533);
            addStudent.Margin = new Padding(3, 4, 3, 4);
            addStudent.Name = "addStudent";
            addStudent.Size = new Size(112, 31);
            addStudent.TabIndex = 26;
            addStudent.Text = "Add Student";
            addStudent.UseVisualStyleBackColor = true;
            addStudent.Click += addStudent_Click;
            // 
            // button2
            // 
            button2.Location = new Point(1143, 532);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(112, 31);
            button2.TabIndex = 27;
            button2.Text = "Search";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // EditModulesButton
            // 
            EditModulesButton.Location = new Point(835, 626);
            EditModulesButton.Name = "EditModulesButton";
            EditModulesButton.Size = new Size(100, 56);
            EditModulesButton.TabIndex = 28;
            EditModulesButton.Text = "Edit Modules";
            EditModulesButton.UseVisualStyleBackColor = true;
            EditModulesButton.Click += EditModulesButton_Click;
            // 
            // MainMenuForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1269, 716);
            Controls.Add(EditModulesButton);
            Controls.Add(button2);
            Controls.Add(addStudent);
            Controls.Add(button1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(StudentsView);
            Controls.Add(DeregisterButton);
            Controls.Add(UpdateButton);
            Controls.Add(StreetAddressBox);
            Controls.Add(PhoneBox);
            Controls.Add(GenderListBox);
            Controls.Add(DateOfBirth);
            Controls.Add(PictureBox);
            Controls.Add(SurnameBox);
            Controls.Add(FirstNameBox);
            Controls.Add(StudentNumberBox);
            Name = "MainMenuForm";
            Text = "MainMenuForm";
            Load += MainMenuForm_Load;
            ((System.ComponentModel.ISupportInitialize)PictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)StudentsView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox StudentNumberBox;
        private TextBox FirstNameBox;
        private TextBox SurnameBox;
        private PictureBox PictureBox;
        private DateTimePicker DateOfBirth;
        private ListBox GenderListBox;
        private MaskedTextBox PhoneBox;
        private TextBox StreetAddressBox;
        private Button UpdateButton;
        private Button DeregisterButton;
        private DataGridView StudentsView;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button button1;
        private Button addStudent;
        private Button button2;
        private Button EditModulesButton;
    }
}