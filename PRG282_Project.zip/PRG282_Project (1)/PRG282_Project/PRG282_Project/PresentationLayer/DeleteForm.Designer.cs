﻿namespace PRG282_Project.PresentationLayer
{
    partial class DeleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            StudentNumberBox = new MaskedTextBox();
            ViewAllButton = new Button();
            StudentView = new DataGridView();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)StudentView).BeginInit();
            SuspendLayout();
            // 
            // StudentNumberBox
            // 
            StudentNumberBox.Location = new Point(154, 58);
            StudentNumberBox.Margin = new Padding(3, 2, 3, 2);
            StudentNumberBox.Mask = "00000000";
            StudentNumberBox.Name = "StudentNumberBox";
            StudentNumberBox.Size = new Size(490, 23);
            StudentNumberBox.TabIndex = 7;
            // 
            // ViewAllButton
            // 
            ViewAllButton.Location = new Point(662, 58);
            ViewAllButton.Margin = new Padding(3, 2, 3, 2);
            ViewAllButton.Name = "ViewAllButton";
            ViewAllButton.Size = new Size(82, 22);
            ViewAllButton.TabIndex = 6;
            ViewAllButton.Text = "Delete";
            ViewAllButton.UseVisualStyleBackColor = true;
            ViewAllButton.Click += ViewAllButton_Click;
            // 
            // StudentView
            // 
            StudentView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            StudentView.Location = new Point(57, 85);
            StudentView.Margin = new Padding(3, 2, 3, 2);
            StudentView.Name = "StudentView";
            StudentView.RowHeadersWidth = 51;
            StudentView.RowTemplate.Height = 29;
            StudentView.Size = new Size(687, 217);
            StudentView.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(57, 62);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 8;
            label1.Text = "Enter Student Id";
            // 
            // DeleteForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(StudentNumberBox);
            Controls.Add(ViewAllButton);
            Controls.Add(StudentView);
            Name = "DeleteForm";
            Text = "DeleteForm";
            Load += DeleteForm_Load;
            ((System.ComponentModel.ISupportInitialize)StudentView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox StudentNumberBox;
        private Button ViewAllButton;
        private DataGridView StudentView;
        private Label label1;
    }
}