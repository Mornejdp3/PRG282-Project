﻿namespace PRG282_Project.PresentationLayer
{
    partial class DisplayModules
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ModuleView = new DataGridView();
            StudentNumberBox = new TextBox();
            SearchButton = new Button();
            RegisterButton = new Button();
            DeregisterButton = new Button();
            ModuleCodeBox = new TextBox();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)ModuleView).BeginInit();
            SuspendLayout();
            // 
            // ModuleView
            // 
            ModuleView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ModuleView.Location = new Point(29, 130);
            ModuleView.Name = "ModuleView";
            ModuleView.RowHeadersWidth = 51;
            ModuleView.RowTemplate.Height = 29;
            ModuleView.Size = new Size(746, 170);
            ModuleView.TabIndex = 0;
            // 
            // StudentNumberBox
            // 
            StudentNumberBox.Location = new Point(319, 56);
            StudentNumberBox.Name = "StudentNumberBox";
            StudentNumberBox.Size = new Size(160, 27);
            StudentNumberBox.TabIndex = 1;
            // 
            // SearchButton
            // 
            SearchButton.Location = new Point(497, 56);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(94, 29);
            SearchButton.TabIndex = 2;
            SearchButton.Text = "Search";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // RegisterButton
            // 
            RegisterButton.Location = new Point(400, 338);
            RegisterButton.Name = "RegisterButton";
            RegisterButton.Size = new Size(94, 29);
            RegisterButton.TabIndex = 3;
            RegisterButton.Text = "Register";
            RegisterButton.UseVisualStyleBackColor = true;
            RegisterButton.Click += RegisterButton_Click;
            // 
            // DeregisterButton
            // 
            DeregisterButton.Location = new Point(518, 338);
            DeregisterButton.Name = "DeregisterButton";
            DeregisterButton.Size = new Size(94, 29);
            DeregisterButton.TabIndex = 4;
            DeregisterButton.Text = "Deregister";
            DeregisterButton.UseVisualStyleBackColor = true;
            DeregisterButton.Click += DeregisterButton_Click;
            // 
            // ModuleCodeBox
            // 
            ModuleCodeBox.Location = new Point(195, 339);
            ModuleCodeBox.Name = "ModuleCodeBox";
            ModuleCodeBox.Size = new Size(160, 27);
            ModuleCodeBox.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(195, 59);
            label1.Name = "label1";
            label1.Size = new Size(118, 20);
            label1.TabIndex = 6;
            label1.Text = "Student Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(366, 97);
            label2.Name = "label2";
            label2.Size = new Size(66, 20);
            label2.TabIndex = 7;
            label2.Text = "Modules";
            // 
            // DisplayModules
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(ModuleCodeBox);
            Controls.Add(DeregisterButton);
            Controls.Add(RegisterButton);
            Controls.Add(SearchButton);
            Controls.Add(StudentNumberBox);
            Controls.Add(ModuleView);
            Name = "DisplayModules";
            Text = "DisplayModules";
            ((System.ComponentModel.ISupportInitialize)ModuleView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView ModuleView;
        private TextBox StudentNumberBox;
        private Button SearchButton;
        private Button RegisterButton;
        private Button DeregisterButton;
        private TextBox ModuleCodeBox;
        private Label label1;
        private Label label2;
    }
}