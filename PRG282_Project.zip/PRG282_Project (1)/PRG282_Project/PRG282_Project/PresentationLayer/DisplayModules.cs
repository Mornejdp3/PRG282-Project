﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_Project.DataAccessLayer;

namespace PRG282_Project.PresentationLayer
{
    public partial class DisplayModules : Form
    {
        public DisplayModules()
        {
            InitializeComponent();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            ModuleDataAccessHandler handler = new ModuleDataAccessHandler();
            int studentNumber = int.Parse(StudentNumberBox.Text);
            
            ModuleView.DataSource = handler.FetchModules(studentNumber);
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            ModuleDataAccessHandler handler = new ModuleDataAccessHandler();
            int studentNumber = int.Parse(StudentNumberBox.Text);
            int moduleCode = int.Parse(ModuleCodeBox.Text);
            
            handler.Register(studentNumber, moduleCode);

        }

        private void DeregisterButton_Click(object sender, EventArgs e)
        {
            ModuleDataAccessHandler handler = new ModuleDataAccessHandler();
            int studentNumber = int.Parse(StudentNumberBox.Text);
            int moduleCode = int.Parse(ModuleCodeBox.Text);

            handler.Deregister(studentNumber, moduleCode);
        }
    }
}
