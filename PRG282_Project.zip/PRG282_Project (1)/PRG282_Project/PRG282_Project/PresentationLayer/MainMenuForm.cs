using System.Data;
using System.Windows.Forms;
using PRG282_Project.DataAccessLayer;
using PRG282_Project.LogicLayer;
using System.IO;
using System.Net;
using System.Globalization;
using PRG282_Project.PresentationLayer;

namespace PRG282_Project
{
    public partial class MainMenuForm : Form
    {


        public MainMenuForm()
        {
            InitializeComponent();

        }



        private void AddButton_Click(object sender, EventArgs e)
        {


        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {

        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            int studentNumber = int.Parse(StudentNumberBox.Text);
            string firstName = FirstNameBox.Text;
            string surname = SurnameBox.Text;
            string picture = PictureBox.ImageLocation;

            int genderchoice = GenderListBox.SelectedIndex;
            string gender = "Female";
            string phone = PhoneBox.Text;
            string streetAddress = StreetAddressBox.Text;
            int moduleCode = 1;


            switch (genderchoice)
            {
                case 0:
                    {
                        gender = "Female";
                    }
                    break;
                case 1:
                    {
                        gender = "Male";
                    }
                    break;
            }


            string format = "yyyy/MM/dd";
            DateTime date = DateTime.ParseExact(DateOfBirth.Text, format, CultureInfo.InvariantCulture);


            Student student = new Student(firstName, surname, picture, gender, phone, streetAddress, date.ToString(), studentNumber, moduleCode);

            StudentDataAccessHandler dataLayerObj = new StudentDataAccessHandler();
            dataLayerObj.Update(student);
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {

        }

        private void DeregisterButton_Click(object sender, EventArgs e)
        {
            DeleteForm deleteForm = new DeleteForm();
            deleteForm.Show();
        }



        private void StudentNumberBox_Leave(object sender, EventArgs e)
        {

        }

        private void PictureBox_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of OpenFileDialog
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            // Set the filter to allow only image files
            openFileDialog1.Filter = "PNG files (*.png)|*.png| JPG files (*.jpg)|*.jpg";

            // The if statement is used to see if a user has selected a file to upload
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Adds the image to the picture box
                PictureBox.ImageLocation = Path.GetFullPath(openFileDialog1.FileName);
            }
            else
            {
                // Warning
                Console.WriteLine("User did not select a file");
            }
        }

        private void addStudent_Click(object sender, EventArgs e)
        {
            int studentNumber = int.Parse(StudentNumberBox.Text);
            string firstName = FirstNameBox.Text;
            string surname = SurnameBox.Text;
            string picture = PictureBox.ImageLocation;

            int genderchoice = GenderListBox.SelectedIndex;
            string gender = "Female";
            string phone = PhoneBox.Text;
            string streetAddress = StreetAddressBox.Text;
            int moduleCode = 1;


            switch (genderchoice)
            {
                case 0:
                    {
                        gender = "Female";
                    }
                    break;
                case 1:
                    {
                        gender = "Male";
                    }
                    break;
            }


            string format = "yyyy/MM/dd";
            DateTime date = DateTime.ParseExact(DateOfBirth.Text, format, CultureInfo.InvariantCulture);


            Student student = new Student(firstName, surname, picture, gender, phone, streetAddress, date.ToString(), studentNumber, moduleCode);

            StudentDataAccessHandler dataLayerObj = new StudentDataAccessHandler();
            dataLayerObj.Create(student);
        }

        private void MainMenuForm_Load(object sender, EventArgs e)
        {
            StudentDataAccessHandler dataLayerObj = new StudentDataAccessHandler();
            DataTable ds = new DataTable();
            ds = dataLayerObj.GetStudents();
            StudentsView.DataSource = ds;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DisplayForm displayForm = new DisplayForm();
            displayForm.Show();
        }

        private void EditModulesButton_Click(object sender, EventArgs e)
        {
            DisplayModules form = new DisplayModules();
            form.Show();
        }
    }
}