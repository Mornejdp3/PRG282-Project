﻿using PRG282_Project.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282_Project.PresentationLayer
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
        }

        private void ViewAllButton_Click(object sender, EventArgs e)
        {
            StudentDataAccessHandler studentDataAccessHandler = new StudentDataAccessHandler();

            int num = int.Parse(StudentNumberBox.Text);

            studentDataAccessHandler.Delete(num);


        }

        private void DeleteForm_Load(object sender, EventArgs e)
        {
            StudentDataAccessHandler dataLayerObj = new StudentDataAccessHandler();
            DataTable ds = new DataTable();
            ds = dataLayerObj.GetStudents();
            StudentView.DataSource = ds;
        }
    }
}
