﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PRG282_Project.LogicLayer;

namespace PRG282_Project.DataAccessLayer
{
    internal class ModuleDataAccessHandler
    {
        string connectionString = @"Data Source=ROGPOG\SQLEXPRESS;Initial Catalog = BelgiumCampusProject; Integrated Security = True";

        public DataTable FetchModules(int studentNumber)
        {
            DataTable ds = new DataTable();

            string query = @"SELECT Modules.ModuleCode, ModuleName, ModuleDescription, YTlinks FROM Modules
                            JOIN StudentModule 
                            ON StudentModule.ModuleCode = Modules.ModuleCode
                            WHERE StudentModule.StudentNumber = @StudentNumber;";

            SqlDataAdapter sqlAdapter = new SqlDataAdapter(query, connectionString);
            sqlAdapter.SelectCommand.Parameters.AddWithValue("@StudentNumber", studentNumber);
            sqlAdapter.Fill(ds);
            return ds;
        }

        public void Register(int studentNumber, int moduleCode)
        {
            string query = $"INSERT INTO StudentModule VALUES ({studentNumber}, {moduleCode});";
        }

        public void Deregister(int studentNumber, int moduleCode)
        {
            string query = $"DELETE StudentModule WHERE StudentNumber = {studentNumber} AND ModuleCode = {moduleCode});";
        }
    }
}
