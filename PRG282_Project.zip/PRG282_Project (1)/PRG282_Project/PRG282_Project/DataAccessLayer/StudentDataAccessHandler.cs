﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PRG282_Project.LogicLayer;
using System.Data;
using System.Data.SqlClient;

namespace PRG282_Project.DataAccessLayer
{
    internal class StudentDataAccessHandler
    {
        string connectionString = @"Data Source=ROGPOG\SQLEXPRESS;Initial Catalog = BelgiumCampusProject; Integrated Security = True";

        public void Create(Student student)
        {
            string createQuery = $"INSERT INTO Students VALUES ({student.StudentNumber}, '{student.Firstname}', '{student.Surname}', '{student.Image}', DOB = @DateOfBirth, '{student.Gender}', '{student.Phone}', '{student.Address}', {student.ModuleCode})";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using(SqlCommand createCommand = new SqlCommand(createQuery, connection )) 
                {
                    createCommand.Parameters.AddWithValue("@DateOfBirth", student.Date);
                    connection.Open();
                    createCommand.ExecuteNonQuery();  
                    connection.Close();
                }
            }
            MessageBox.Show("Student has been added");
        }

        public void Update(Student student)
        {
            string updateQuery = $"UPDATE Students SET FirstName = '{student.Firstname}', Surname = '{student.Surname}', '{student.Image}', DOB = @DateOfBirth, Gender = '{student.Gender}', Phone = '{student.Phone}', StudentAddress = '{student.Address}', ModuleCode = {student.ModuleCode} WHERE StudentNumber = {student.StudentNumber}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@DateOfBirth", student.Date);
                    connection.Open();
                    updateCommand.ExecuteNonQuery();
                    connection.Close();
                }
            }

            MessageBox.Show($"Student {student.StudentNumber} been updated");
        }
    
        

        public DataTable Search(int studentNumber)
        {
            string searchQuery = $"SELECT * FROM Students WHERE StudentNumber = {studentNumber}";
            DataTable table = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter(searchQuery, connection))
                {
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@StudentNumber", studentNumber);
                    connection.Open();
                    dataAdapter.Fill(table);
                    connection.Close();
                }
            }

            return table;
        }
   
        public void Delete(int studentNumber)
        {
            string deleteQuery = $"DELETE Students WHERE StudentNumber = {studentNumber}";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using(SqlCommand deleteCommand = new SqlCommand(deleteQuery, connection))
                {
                    deleteCommand.Parameters.AddWithValue("@StudentNumber", studentNumber);

                    connection.Open();
                    deleteCommand.ExecuteNonQuery();
                    connection.Close();
                }
            }
            MessageBox.Show("Student has been deleted");
        }

        public DataTable GetStudents()
        {
            DataTable ds = new DataTable();
           
            string query = @"SELECT * FROM Students; SELECT * FROM Modules";

            SqlDataAdapter sqlAdapter = new SqlDataAdapter(query, connectionString);               
            sqlAdapter.Fill(ds); 
            return ds; 
            
        }


    }
}
