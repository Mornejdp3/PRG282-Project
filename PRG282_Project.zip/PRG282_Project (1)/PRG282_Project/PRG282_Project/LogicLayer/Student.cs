﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG282_Project.LogicLayer
{
    internal class Student
    {
        string firstname, surname, image, gender, phone, address, date;
        int studentNumber, moduleCode;

        

        public Student () { }

        public Student(string firstname, string surname, string image, string gender, string phone, string address, string date, int studentNumber, int moduleCode)
        {
            this.Firstname = firstname;
            this.Surname = surname;
            this.Image = image;
            this.Gender = gender;
            this.Phone = phone;
            this.Address = address;
            this.Date = date;
            this.StudentNumber = studentNumber;
            this.ModuleCode = moduleCode;
        }

        public string Firstname { get => firstname; set => firstname = value; }
        public string Surname { get => surname; set => surname = value; }
        public string Image { get => image; set => image = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Address { get => address; set => address = value; }
        public string Date { get => date; set => date = value; }
        public int StudentNumber { get => studentNumber; set => studentNumber = value; }
        public int ModuleCode { get => moduleCode; set => moduleCode = value; }
    }
}
